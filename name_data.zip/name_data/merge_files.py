import fileinput
import glob
import pandas as pd 

def read_file(fn):
    """
    Reads in a name text file for a given year to return a dataframe. 
    
    Params:
        fn(str): The name of text file
    Returns:
        A dataframe of the name data with columns 
        ['Name', 'Gender', 'Count']
    
    """
    df = pd.read_csv(fn)
    df.columns = ['Name', 'Gender', 'Count']
    year = fn.split(".txt")[0][3:]
    df['Year'] = year
    return df

def main():
    file_list = glob.glob("yob*.txt") # Get all txt files with name including 'yob'
    dfs = [read_file(f) for f in file_list] # Convert each text file to a dataframe
    df = pd.concat(dfs) # Combine the dataframes 
    df.to_csv("merged.csv") # Write the output to a csv file

main()
        
if __name__ == "__main__":
    main()